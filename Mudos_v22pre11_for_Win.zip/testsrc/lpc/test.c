class IMyTest {
    int  number; 
    void Go();   // add number
    string CallTestFunc();
    void AssignInstance(class IMyTest);
} = "{E2A87B0D-EC31-11D1-A9D4-444553540000}";


class IMyTest2 {
    int  number2;
    void Go2();  // add number, add number2
    void AssignInstance(class IMyTest2);
} = "{E2A87B0D-EC31-11D1-A9D4-444553540000}";

class IMyTest local;
string testfunc(string s)
{
    return s+local->number;
}

test1()
{
    class IMyTest ab;
    ab=new(class IMyTest);
    ab->number=1;
    ab->Go();
    printf("%d\n",ab->number);
}

test2()
{
    class IMyTest ab;
    ab=new(class IMyTest);
    ab->number=1;
    local=ab;
    printf("%s\n",ab->CallTestFunc());
}

test3()
{
    class IMyTest a;
    class IMyTest2 b;
    a=new(class IMyTest);
    b=new(class IMyTest2);
    a->number=1;
    b->number2=1;
    a->Go();
    b->Go2();
    printf("%d %d\n",a->number,b->number2);
}

test4()
{
    class IMyTest a;
    class IMyTest2 b;
    a=new(class IMyTest);
    b=new(class IMyTest2);
    b->AssignInstance(a);
    a->number=1;
    b->number2=1;
    a->Go();
    b->Go2();
    printf("%d %d\n",a->number,b->number2);
}

test5()
{
    class IMyTest a;
    class IMyTest2 b;
    a=new(class IMyTest);
    b=new(class IMyTest2);
    a->AssignInstance(b);
    a->number=1;
    b->number2=1;
    a->Go();
    b->Go2();
    printf("%d %d\n",a->number,b->number2);
}

test()
{
    test1();
    test2();
    test3();
    test4();
    test5();
}
