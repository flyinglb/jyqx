// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IMValue wrapper class

class IMValue : public COleDispatchDriver
{
public:
	IMValue() {}		// Calls COleDispatchDriver default constructor
	IMValue(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMValue(const IMValue& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetName();
	long GetType();
	void CreateNumber();
	void CreateString();
	void CreateReal();
	void CreateArray(long size);
	void CreateMapping();
	LPDISPATCH GetExtend();
};
/////////////////////////////////////////////////////////////////////////////
// IMNumber wrapper class

class IMNumber : public COleDispatchDriver
{
public:
	IMNumber() {}		// Calls COleDispatchDriver default constructor
	IMNumber(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMNumber(const IMNumber& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetNumber();
	void SetNumber(long nNewValue);
};
/////////////////////////////////////////////////////////////////////////////
// IMString wrapper class

class IMString : public COleDispatchDriver
{
public:
	IMString() {}		// Calls COleDispatchDriver default constructor
	IMString(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMString(const IMString& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetString();
	void SetString(LPCTSTR lpszNewValue);
};
/////////////////////////////////////////////////////////////////////////////
// IMReal wrapper class

class IMReal : public COleDispatchDriver
{
public:
	IMReal() {}		// Calls COleDispatchDriver default constructor
	IMReal(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMReal(const IMReal& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	float GetReal();
	void SetReal(float newValue);
};
/////////////////////////////////////////////////////////////////////////////
// IMObject wrapper class

class IMObject : public COleDispatchDriver
{
public:
	IMObject() {}		// Calls COleDispatchDriver default constructor
	IMObject(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMObject(const IMObject& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetObjectName();
	long GetObjectLoadTime();
	LPDISPATCH GetEnvironment();
	long GetValueCount();
	LPDISPATCH GetValue(long id);
};
/////////////////////////////////////////////////////////////////////////////
// IMClass wrapper class

class IMClass : public COleDispatchDriver
{
public:
	IMClass() {}		// Calls COleDispatchDriver default constructor
	IMClass(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMClass(const IMClass& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetMemberCount();
	LPDISPATCH GetMember(long id);
};
/////////////////////////////////////////////////////////////////////////////
// IMMapping wrapper class

class IMMapping : public COleDispatchDriver
{
public:
	IMMapping() {}		// Calls COleDispatchDriver default constructor
	IMMapping(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMMapping(const IMMapping& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetMappingCount();
	LPDISPATCH GetMappingKeys();
	LPDISPATCH Query(LPCTSTR sKey);
	void Map(LPCTSTR sKey, LPDISPATCH pVal);
};
/////////////////////////////////////////////////////////////////////////////
// IMArray wrapper class

class IMArray : public COleDispatchDriver
{
public:
	IMArray() {}		// Calls COleDispatchDriver default constructor
	IMArray(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMArray(const IMArray& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetItemCount();
	LPDISPATCH GetItem(long id);
};
/////////////////////////////////////////////////////////////////////////////
// IMBuffer wrapper class

class IMBuffer : public COleDispatchDriver
{
public:
	IMBuffer() {}		// Calls COleDispatchDriver default constructor
	IMBuffer(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMBuffer(const IMBuffer& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
};
/////////////////////////////////////////////////////////////////////////////
// IMProgram wrapper class

class IMProgram : public COleDispatchDriver
{
public:
	IMProgram() {}		// Calls COleDispatchDriver default constructor
	IMProgram(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMProgram(const IMProgram& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetFunctionCount();
	LPDISPATCH GetFunction(long id);
	CString GetFileName();
};
/////////////////////////////////////////////////////////////////////////////
// IMFunction wrapper class

class IMFunction : public COleDispatchDriver
{
public:
	IMFunction() {}		// Calls COleDispatchDriver default constructor
	IMFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMFunction(const IMFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetName();
	long GetParamCount();
	void AddParam(LPDISPATCH pVal);
	void ClearParam();
	LPDISPATCH GetRet();
	void Apply();
};
/////////////////////////////////////////////////////////////////////////////
// IMudos wrapper class

class IMudos : public COleDispatchDriver
{
public:
	IMudos() {}		// Calls COleDispatchDriver default constructor
	IMudos(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMudos(const IMudos& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	LPDISPATCH GetCurrentObject();
	LPDISPATCH GetCurrentProgram();
	void SetCommHook(long pFunc);
	void Shutdown();
	LPDISPATCH GetUsers();
	LPDISPATCH GetUser(long UserId);
	long GetHeartBeat();
	void SetHeartBeat(long nNewValue);
	LPDISPATCH NewValue();
};
