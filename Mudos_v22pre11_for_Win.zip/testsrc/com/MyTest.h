// MyTest.h: Definition of the CMyTest class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYTEST_H__5C0B4CA3_ED86_11D1_B76C_00002144A0A8__INCLUDED_)
#define AFX_MYTEST_H__5C0B4CA3_ED86_11D1_B76C_00002144A0A8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "resource.h"       // main symbols
#include "mudos.h"

/////////////////////////////////////////////////////////////////////////////
// CMyTest

class CMyTest : 
	public CComDualImpl<IMyTest, &IID_IMyTest, &LIBID_COMLib>, 
	public CComDualImpl<IMyTest2, &IID_IMyTest2, &LIBID_COMLib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CComCoClass<CMyTest,&CLSID_MyTest>
{
	IMudos * m_os;
public:
	CMyTest() {m_os=NULL;}
	~CMyTest(){if(m_os)delete m_os;}
BEGIN_COM_MAP(CMyTest)
	COM_INTERFACE_ENTRY2(IDispatch,IMyTest)
	COM_INTERFACE_ENTRY(IMyTest)
	COM_INTERFACE_ENTRY(IMyTest2)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(CMyTest) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation. 

DECLARE_REGISTRY_RESOURCEID(IDR_MyTest)
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMyTest
public:
    int number;
	int number2;
	STDMETHOD(CallTestFunc)(/*[out,retval]*/ BSTR * pVal);
	STDMETHOD(get_number2)(/*[out, retval]*/ int *pVal);
	STDMETHOD(put_number2)(/*[in]*/ int newVal);
	STDMETHOD(get_number)(/*[out, retval]*/ int *pVal);
	STDMETHOD(put_number)(/*[in]*/ int newVal);
	STDMETHOD(Go)();
	STDMETHOD(OnFreeObject)();
	STDMETHOD(OnNewObject)(/*[in]*/ IDispatch *pVal);

    STDMETHOD(Go2)();
};

#endif // !defined(AFX_MYTEST_H__5C0B4CA3_ED86_11D1_B76C_00002144A0A8__INCLUDED_)
