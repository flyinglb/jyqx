// MyTest.cpp : Implementation of CComApp and DLL registration.

#include "stdafx.h"
#include "com.h"
#include "MyTest.h"

/////////////////////////////////////////////////////////////////////////////
//

STDMETHODIMP CMyTest::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMyTest,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMyTest::OnNewObject(IDispatch * pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	if(!m_os)m_os=new IMudos(pVal);

	return S_OK;
}

STDMETHODIMP CMyTest::OnFreeObject()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	return S_OK;
}

STDMETHODIMP CMyTest::Go()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    number++;
	return S_OK;
}


STDMETHODIMP CMyTest::Go2()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    number2++;
    number++;

	return S_OK;
}


STDMETHODIMP CMyTest::get_number(int * pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    *pVal=number;

	return S_OK;
}

STDMETHODIMP CMyTest::put_number(int newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    number=newVal;

	return S_OK;
}

STDMETHODIMP CMyTest::get_number2(int * pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    *pVal=number2;

	return S_OK;
}

STDMETHODIMP CMyTest::put_number2(int newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    number2=newVal;

	return S_OK;
}

STDMETHODIMP CMyTest::CallTestFunc(BSTR * pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	CString cs;

	IMProgram prog(m_os->GetCurrentProgram());
	for(int i=0;i<prog.GetFunctionCount();i++){
		IMFunction func(prog.GetFunction(i));
		if(func.GetName()=="testfunc"){
			IMValue v2(m_os->NewValue());
			v2.CreateString();
			IMString str(v2.GetExtend());
			str.SetString("ccc");

			func.AddParam(v2.m_lpDispatch);
			func.Apply();
			IMValue v(func.GetRet());
			if(v.GetType()==2){
				IMString s(v.GetExtend());
				cs=s.GetString();
                int count=MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,cs,-1,NULL,0);
                *pVal=SysAllocStringLen(NULL,count);
                MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,cs,-1,*pVal,count);
			}
            break;
		}
	}
	return S_OK;
}
